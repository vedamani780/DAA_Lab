#include<stdio.h>
int main(){
	int n,j,key;
	int arr[n];
	printf("Enter no.of elements:");
	scanf("%d",&n);
	printf("Enter elements:");
	for(int i=0;i<n;i++){
		scanf("%d",&arr[i]);
	}
	key=arr[1];
	j=0;
	while(j>=0 && arr[j]>key){
		arr[j+1]=arr[j];
		j--;
	}
	arr[j+1]=key;
	printf("Array after inserting second element:");
	for(int i=0;i<n;i++){
		printf("%d ",arr[i]);
	}
}
