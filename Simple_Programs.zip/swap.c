#include<stdio.h>
int main(){
	int a,b,temp;
	printf("Enter 2 elements:");
	scanf("%d %d",&a,&b);
	printf("Before Swapping:");
	printf("%d %d", a,b);
	temp=a;
	a=b;
	b=temp;
	printf("\nAfter Swapping:%d %d\n", a,b);
}
