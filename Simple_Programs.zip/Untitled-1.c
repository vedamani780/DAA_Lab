/* Insertion Sort
#include<stdio.h>
int main(){
    int n,key,j;
    int arr[n];
    printf("Enter no.of elements:");
    scanf("%d",&n);
    printf("Enter elements:");
    for(int i=0;i<n;i++){
        scanf("%d",&arr[i]);
    }
    for(int i=0;i<n;i++){
        key=arr[i];
        j=i-1;
        while(j>=0 && arr[j]>key){
            arr[j+1]=arr[j];
            j--;
        }
        arr[j+1]=key;
    }
    printf("Array after insertion sort:");
    for(int i=0;i<n;i++){
        printf("%d ",arr[i]);
    }
}*/
// Buuble Sort
#include<stdio.h>
int main(){
    int i,temp,n;
    int arr[20];
    printf("Enter no.of elements:");
    scanf("%d",&n);
    printf("Enter elements:");
    for(int i=0;i<n;i++){
        scanf("%d",&arr[i]);
    }
    for(int i=0;i<n-1;i++){
        if(arr[i]>arr[i+1]){
            temp=arr[i];
            arr[i]=arr[i+1];
            arr[i+1]=temp;
        }
    }
    printf("Array after Bubble Sort:");
    for(int i=0;i<n;i++){
        printf("%d ",arr[i]);
    }
    return 0;
}