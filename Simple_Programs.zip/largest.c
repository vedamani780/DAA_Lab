#include<stdio.h>
int main(){
	int n,largest;
	int arr[20];
	printf("Enter no.of elements:");
	scanf("%d",&n);
	printf("Enter %d Elements:",n);
	for(int i=0;i<n;i++){
		scanf("%d",&arr[i]);
	}
	largest=arr[1];
	for(int i=1;i<n;i++){
		if(arr[i]>largest){
			largest=arr[i];
		}
	}
	printf("Largest element= %d", largest);
	return 0;
} 
