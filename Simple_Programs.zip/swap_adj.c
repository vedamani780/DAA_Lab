#include<stdio.h>
int main(){
	int n,temp;
	int arr[n];
	printf("Enter no.of elements:");
	scanf("%d",&n);
	printf("Enter the elemnets:");
	for(int i=0;i<n;i++){
		scanf("%d",&arr[i]);
	}
	for(int i=0;i<n-1;i+=2){//if we put 1 then when arr is odd first value stays constant
		temp=arr[i];
		arr[i]=arr[i+1];
		arr[i+1]=temp;
	}
	printf("After swapping:");
	for(int i=0;i<n;i++){
		printf("%d ",arr[i]);
	}
}
