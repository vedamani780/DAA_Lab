#include<stdio.h>
int main(){
	int n;
	int arr[n];
	printf("Enter no.of elements:");
	scanf("%d",&n);
	printf("Enter the elements:");
	for(int i=0;i<n;i++){
		scanf("%d",&arr[i]);
	}
	printf("Array in Reverse order:");
	for(int i=n-1;i>=0;i--){
		printf("%d ",arr[i]);
	}
	return 0;
}
