#include<stdio.h>
void bubbleSort(int arr[], int n) {
    int temp;
    for(int i = 0; i < n - 1; i++) {
        for(int j = 0; j < n - 1 - i; j++) {
            if(arr[j] > arr[j + 1]) {
                temp = arr[j];
                arr[j] = arr[j + 1];
                arr[j + 1] = temp;
            }
        }
    }
}

void selectionSort(int arr[], int n) {
    int i, j, small, temp;
    for(i = 0; i < n - 1; i++) {
        small = i;
        for(j = i + 1; j < n; j++) {
            if(arr[j] < arr[small]) {
                small= j;
            }
        }
        temp = arr[i];
        arr[i] = arr[small];
        arr[small] = temp;
    }
}

void insertionSort(int arr[], int n) {
    int i, key, j;
    for(i = 1; i < n; i++) {
        key = arr[i];
        j = i - 1;
        while(j >= 0 && arr[j] > key) {
            arr[j + 1] = arr[j];
            j--;
        }
        arr[j + 1] = key;
    }
}

void copy(int src[], int dest[], int n) {
    int i;
    for(i = 0; i < n; i++) {
        dest[i] = src[i];
    }
}

void print(int arr[], int n) {
    int i;
    for(i = 0; i < n; i++) {
        printf("%d ", arr[i]);
    }
    printf("\n");
}

int main() {
    int n, i;
    int original[50], b[50], s[50], in[50];
    printf("Enter number of elements: ");
    scanf("%d", &n);
    printf("Enter elements: ");
    for(i = 0; i < n; i++) {
        scanf("%d", &original[i]);
    }

    copy(original, b, n);
    copy(original, s, n);
    copy(original, in, n);

    bubbleSort(b, n);
    selectionSort(s, n);
    insertionSort(in, n);

    printf("Bubble Sort: ");
    print(b, n);
    printf("Selection Sort: ");
    print(s, n);
    printf("Insertion Sort: ");
    print(in, n);

    return 0;
}

