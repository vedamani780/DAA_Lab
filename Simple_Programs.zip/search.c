#include<stdio.h>
int main(){
	int n,key,found=0;
	int arr[n];
	printf("Enter no.of elements:");
	scanf("%d",&n);
	printf("Enter elements:");
	for(int i=0;i<n;i++){
		scanf("%d",&arr[i]);
	}
	printf("Enter the element to search:");
	scanf("%d",&key);
	for(int i=0;i<n;i++){
		if(arr[i]==key){
			found=1;
			printf("Element is found at position %d",i+1);
			break;
		}
	}
	if(found==0){
		printf("Element not found\n");
	}
}
