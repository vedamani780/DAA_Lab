#include<stdio.h>
int main(){
	int n,sum=0;
	int arr[n];
	printf("Enter the no.of elements:");
	scanf("%d",&n);
	printf("Enter elements:");
	for(int i=0;i<n;i++){
		scanf("%d",&arr[i]);
		sum=sum+arr[i];
	}
	printf("Sum=%d",sum);
}
