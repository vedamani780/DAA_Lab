#include<stdio.h>
int main(){
	int n,key,j;
	int arr[40];
	printf("Enter no.of elements:");
	scanf("%d",&n);
	printf("Enter elements:");
	for(int i=0;i<n;i++){
		scanf("%d",&arr[i]);
	}
	for(int i=0;i<n;i++){
		key=arr[i];
		j=i-1;
		while(j>=0 && arr[j]>key){
		arr[j+1]=arr[j];
		j--;
		}
	arr[j+1]=key;
	}
	printf("Array after insertion sort:");
	for(int i=0;i<n;i++){
		printf("%d ",arr[i]);
	}
}
