#include<stdio.h>
int main(){
	int n,small,temp;
	int arr[30];
	printf("Enter no.of elements:");
	scanf("%d",&n);
	printf("Enter elements:");
	for(int i=0;i<n;i++){
		scanf("%d",&arr[i]);
	}
	small=0;
	for(int i=1;i<n;i++){
		//small=i;
		if(arr[i]<arr[small]){
			small=i;
		}
	}
	temp=arr[0];
	arr[0]=arr[small];
	arr[small]=temp;
	printf("Array after sorting:");
	for(int i=0;i<n;i++){
		printf("%d ",arr[i]);
	}
	return 0;
}
		
		
