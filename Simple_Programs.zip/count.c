#include <stdio.h>
int main() {
    int n, even = 0, odd = 0;
    int arr[100];
    printf("Enter number of elements: ");
    scanf("%d", &n);
    printf("Enter elements: ");
    for(int i = 0; i < n; i++) {
        scanf("%d", &arr[i]);
        if(arr[i] % 2 == 0) {
            even++;
        } else {
            odd++;
        }
    }
    printf("Even count = %d\n", even);
    printf("Odd count = %d", odd);
    return 0;
}
