#include<stdio.h>
int main(){
	int n,temp;
	int arr[n];
	printf("Enter no.of elements:");
	scanf("%d",&n);
	printf("Enter elements:");
	for(int i=0;i<n;i++){
		scanf("%d",&arr[i]);
	}
	for(int i=0;i<n-1;i++){
		if(arr[i]>arr[i+1]){
			temp=arr[i];
			arr[i]=arr[i+1];
			arr[i+1]=temp;
		}
	}
	printf("Array after bubble sort:");
	for(int i=0;i<n;i++){
		printf("%d ",arr[i]);
	}
	return 0;
}
