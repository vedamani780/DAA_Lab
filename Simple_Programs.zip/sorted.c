#include<stdio.h>
int main(){
	int n,sorted=0;
	int arr[30];
	printf("Enter no.of elements:");
	scanf("%d",&n);
	printf("Enter elements:");
	for(int i=0;i<n;i++){
		scanf("%d",&arr[i]);
	}
	for(int i=0;i<n-1;i++){
		if(arr[i]>arr[i+1]){
			sorted=1;
			break;
		}
	}
	if(sorted==0){
		printf("Array is sorted");
	}else{
		printf("Array is not sorted");
	}
}
