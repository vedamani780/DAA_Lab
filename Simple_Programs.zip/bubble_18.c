#include<stdio.h>
int main(){
	int n,temp,comparisions;
	int arr[40];
	printf("Enter no.of elements:");
	scanf("%d",&n);
	printf("Enter elements:");
	for(int i=0;i<n;i++){
		scanf("%d",&arr[i]);
	}
	for(int i=0;i<n-1;i++){
		for(int j=0;j<n-1-i;j++){
			comparisions++;
			if(arr[j]>arr[j+1]){
				temp=arr[j];
				arr[j]=arr[j+1];
				arr[j+1]=temp;
			}
		}
	}
	printf("Sorted Array:");
	for(int i=0;i<n;i++){
		printf("%d ",arr[i]);
	}
	printf("\nComparisions:%d",comparisions);
	return 0;
}
