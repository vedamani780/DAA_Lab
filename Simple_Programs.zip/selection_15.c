#include<stdio.h>
int main(){
	int small,n,temp;
	int arr[n];
	printf("Enter no.of elements:");
	scanf("%d",&n);
	printf("Enter elements:");
	for(int i=0;i<n;i++){
		scanf("%d",&arr[i]);
	}
	for(int i=0;i<n-1;i++){
		small=i;
		for(int j=i+1;j<n;j++){
			if(arr[j]<arr[small]){
				small=j;
			}
		}
		temp=arr[i];
		arr[i]=arr[small];
		arr[small]=temp;
	}
	printf("Array after selection sort:");
	for(int i=0;i<n;i++){
		printf("%d ",arr[i]);
	}
}
