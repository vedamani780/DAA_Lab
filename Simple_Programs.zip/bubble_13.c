#include<stdio.h>
int main(){
	int n,temp,swap;
	int arr[n];
	printf("Enter no.of elements");
	scanf("%d",&n);
	printf("Enter elements:");
	for(int i=0;i<n; i++){
		scanf("%d",&arr[i]);
	}
	for(int i=0;i<n-1; i++){
		swap=0;
		for(int j=0;j<n-1-i;j++){
			if(arr[j]>arr[j+1]){
				temp=arr[j];
				arr[j]=arr[j+1];
				arr[j+1]=temp;
				swap=1;
			}
		}
		if(swap==0){
			break;
		}
	}
	printf("Sorted Array:");
	for(int i=0;i<n;i++){
		printf("%d ",arr[i]);
	}
}
