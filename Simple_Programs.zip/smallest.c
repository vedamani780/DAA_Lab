#include<stdio.h>
int main(){
	int n,small;
	int arr[30];
	printf("Enter no.of elements:");
	scanf("%d",&n);
	printf("Enter elements:");
	for(int i=0;i<n;i++){
		scanf("%d",&arr[i]);
	}
	small=arr[0];
	for(int i=1;i<n;i++){
		if(arr[i]<small){
			small=arr[i];
		}
	}
	printf("Smallest element= %d",small);
}
