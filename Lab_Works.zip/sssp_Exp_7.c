#include <stdio.h>

#define INF 99999
#define MAX 100

void dijkstra(int graph[MAX][MAX], int n, int source)
{
    int distance[MAX], visited[MAX];
    int i, j, min, u;

    // Initialize distances and visited array
    for (i = 0; i < n; i++)
    {
        distance[i] = graph[source][i];
        visited[i] = 0;
    }

    distance[source] = 0;
    visited[source] = 1;

    // Find shortest paths
    for (i = 1; i < n; i++)
    {
        min = INF;
        u = -1;

        // Find the unvisited vertex with minimum distance
        for (j = 0; j < n; j++)
        {
            if (!visited[j] && distance[j] < min)
            {
                min = distance[j];
                u = j;
            }
        }

        if (u == -1)
            break;

        visited[u] = 1;

        // Update distances of adjacent vertices
        for (j = 0; j < n; j++)
        {
            if (!visited[j] &&
                graph[u][j] != INF &&
                distance[u] + graph[u][j] < distance[j])
            {
                distance[j] = distance[u] + graph[u][j];
            }
        }
    }

    // Display shortest distances
    printf("\nShortest distances from source vertex %d:\n", source);

    for (i = 0; i < n; i++)
    {
        if (distance[i] == INF)
            printf("Vertex %d -> Not reachable\n", i);
        else
            printf("Vertex %d -> %d\n", i, distance[i]);
    }
}

int main()
{
    int graph[MAX][MAX];
    int n, source;
    int i, j;

    printf("Enter number of vertices: ");
    scanf("%d", &n);

    printf("Enter the adjacency matrix:\n");
    printf("(Enter 99999 for no edge)\n");

    for (i = 0; i < n; i++)
    {
        for (j = 0; j < n; j++)
        {
            scanf("%d", &graph[i][j]);
        }
    }

    printf("Enter source vertex: ");
    scanf("%d", &source);

    dijkstra(graph, n, source);

    return 0;
}