#include <stdio.h>

struct Edge
{
    int u;
    int v;
    int weight;
};

int parent[20];

int find(int i)
{
    while(parent[i] != i)
        i = parent[i];

    return i;
}

void union_set(int u, int v)
{
    int root_u = find(u);
    int root_v = find(v);

    parent[root_u] = root_v;
}

int main()
{
    struct Edge edges[50];
    struct Edge temp;

    int n, e;
    int i, j;
    int count = 0;
    int total = 0;
    int u, v;

    printf("Enter number of vertices: ");
    scanf("%d", &n);

    printf("Enter number of edges: ");
    scanf("%d", &e);

    printf("Enter edges (source destination weight):\n");

    for(i = 0; i < e; i++)
    {
        scanf("%d %d %d",
              &edges[i].u,
              &edges[i].v,
              &edges[i].weight);
    }

    /* Sort edges according to weight */
    for(i = 0; i < e - 1; i++)
    {
        for(j = 0; j < e - i - 1; j++)
        {
            if(edges[j].weight > edges[j + 1].weight)
            {
                temp = edges[j];
                edges[j] = edges[j + 1];
                edges[j + 1] = temp;
            }
        }
    }

    /* Initially every vertex is its own parent */
    for(i = 0; i < n; i++)
        parent[i] = i;

    printf("\nEdges in Minimum Spanning Tree:\n");

    for(i = 0; i < e && count < n - 1; i++)
    {
        u = edges[i].u;
        v = edges[i].v;

        if(find(u) != find(v))
        {
            printf("%d - %d : %d\n",
                   u, v, edges[i].weight);

            total = total + edges[i].weight;

            union_set(u, v);

            count++;
        }
    }

    printf("\nMinimum cost = %d\n", total);

    return 0;
}