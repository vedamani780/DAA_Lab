#include <stdio.h>

int w[20], x[20], n, target;

void Subsets(int i, int currentSum, int remainingSum)
{
    // Include the current element
    x[i] = 1;

    if (currentSum + w[i] == target)
    {
        // Print the solution
        printf("{ ");
        for (int j = 0; j <= i; j++)
        {
            if (x[j] == 1)
                printf("%d ", w[j]);
        }
        printf("}\n");
    }
    else if (i + 1 < n && currentSum + w[i] + w[i + 1] <= target)
    {
        Subsets(i + 1,
                     currentSum + w[i],
                     remainingSum - w[i]);
    }

    // Exclude the current element
    if (i + 1 < n &&
        currentSum + remainingSum - w[i] >= target &&
        currentSum + w[i + 1] <= target)
    {
        x[i] = 0;

        Subsets(i + 1,
                     currentSum,
                     remainingSum - w[i]);
    }
}

int main()
{
    printf("Enter number of elements: ");
    scanf("%d", &n);

    printf("Enter elements in increasing order:\n");
    int total = 0;

    for (int i = 0; i < n; i++)
    {
        scanf("%d", &w[i]);
        total += w[i];
    }

    printf("Enter target sum: ");
    scanf("%d", &target);

    printf("\nSubsets whose sum is %d:\n", target);

    Subsets(0, 0, total);

    return 0;
}