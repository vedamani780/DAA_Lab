#include <stdio.h>

int main()
{
    int n, i, j, k;
    int a[10][10];

    printf("Enter number of vertices: ");
    scanf("%d", &n);

    printf("Enter adjacency matrix:\n");

    for(i = 0; i < n; i++)
    {
        for(j = 0; j < n; j++)
        {
            scanf("%d", &a[i][j]);
        }
    }

    // Warshall's Algorithm
    for(k = 0; k < n; k++)
    {
        for(i = 0; i < n; i++)
        {
            for(j = 0; j < n; j++)
            {
                if(a[i][k] == 1 && a[k][j] == 1)
                {
                    a[i][j] = 1;
                }
            }
        }
    }

    printf("\nTransitive Closure:\n");

    for(i = 0; i < n; i++)
    {
        for(j = 0; j < n; j++)
        {
            printf("%1d ", a[i][j]);
        }
        printf("\n");
    }

    return 0;
}