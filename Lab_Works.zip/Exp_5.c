#include <stdio.h>
#include <limits.h>

#define MAX 15

int n;
int cost[MAX][MAX];
int dp[1 << MAX][MAX];

int tsp(int mask, int pos)
{
    // All cities have been visited
    if (mask == (1 << n) - 1)
        return cost[pos][0];

    // If already calculated
    if (dp[mask][pos] != -1)
        return dp[mask][pos];

    int ans = INT_MAX;

    // Try visiting every unvisited city
    for (int city = 0; city < n; city++)
    {
        if ((mask & (1 << city)) == 0)
        {
            int newCost = cost[pos][city]
                        + tsp(mask | (1 << city), city);

            if (newCost < ans)
                ans = newCost;
        }
    }

    return dp[mask][pos] = ans;
}

int main()
{
    printf("Enter number of cities: ");
    scanf("%d", &n);

    printf("Enter the cost matrix:\n");

    for (int i = 0; i < n; i++)
    {
        for (int j = 0; j < n; j++)
        {
            scanf("%d", &cost[i][j]);
        }
    }

    // Initialize DP table
    for (int i = 0; i < (1 << n); i++)
    {
        for (int j = 0; j < n; j++)
        {
            dp[i][j] = -1;
        }
    }

    // Start from city 0
    int minimumCost = tsp(1, 0);

    printf("\nMinimum travelling cost = %d\n", minimumCost);

    return 0;
}