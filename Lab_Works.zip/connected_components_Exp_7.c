#include<stdio.h>
int graph[20][20];
int visited[20];
int n;
void DFS(int v){
    int i;
    visited[v]=1;
    printf("%d",v+1);
    for (i=0;i<n;i++){
        if(graph[v][i]==1 && !visited[i]){
            DFS(i);
        }
    }
}
int main(){
    int i,j,components=0;
    printf("Enter no.of vertices:");
    scanf("%d",&n);
    printf("Enter adjacency matrix:\n");
    for(i=0;i<n;i++){
        for(j=0;j<n;j++)
            scanf("%d",&graph[i][j]);
    
    }
    for(i=0;i<n;i++)
        visited[i]=0;
    printf("\n connected components:\n");
    for(i=0;i<n;i++){
        if(!visited[i]){
            components ++;
            printf("Component %d: ", components);
            DFS(i);
            printf("\n");
        }
    }
    printf("\nTotal connected components=%d \n",components);
    return 0;
}