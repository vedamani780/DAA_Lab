#include <stdio.h>

#define N 9

// Check whether placing num is safe
int isSafe(int sudoku[N][N], int row, int col, int num)
{
    int i, j;

    // Check row
    for (i = 0; i < N; i++)
        if (sudoku[row][i] == num)
            return 0;

    // Check column
    for (i = 0; i < N; i++)
        if (sudoku[i][col] == num)
            return 0;

    // Check 3x3 sub-grid
    int startRow = row - row % 3;
    int startCol = col - col % 3;

    for (i = 0; i < 3; i++)
        for (j = 0; j < 3; j++)
            if (sudoku[startRow + i][startCol + j] == num)
                return 0;

    return 1;
}

// Solve Sudoku using Backtracking
int solveSudoku(int sudoku[N][N])
{
    int row, col;
    int found = 0;

    // Find an empty cell
    for (row = 0; row < N; row++)
    {
        for (col = 0; col < N; col++)
        {
            if (sudoku[row][col] == 0)
            {
                found = 1;
                break;
            }
        }

        if (found)
            break;
    }

    // No empty cell means Sudoku is solved
    if (!found)
        return 1;

    // Try numbers 1 to 9
    for (int num = 1; num <= 9; num++)
    {
        if (isSafe(sudoku, row, col, num))
        {
            sudoku[row][col] = num;

            if (solveSudoku(sudoku))
                return 1;

            // Backtrack
            sudoku[row][col] = 0;
        }
    }

    return 0;
}

// Display Sudoku
void printSudoku(int sudoku[N][N])
{
    for (int i = 0; i < N; i++)
    {
        for (int j = 0; j < N; j++)
            printf("%d ", sudoku[i][j]);

        printf("\n");
    }
}

int main()
{
    int sudoku[N][N] =
    {
        {5, 3, 0, 0, 7, 0, 0, 0, 0},
        {6, 0, 0, 1, 9, 5, 0, 0, 0},
        {0, 9, 8, 0, 0, 0, 0, 6, 0},
        {8, 0, 0, 0, 6, 0, 0, 0, 3},
        {4, 0, 0, 8, 0, 3, 0, 0, 1},
        {7, 0, 0, 0, 2, 0, 0, 0, 6},
        {0, 6, 0, 0, 0, 0, 2, 8, 0},
        {0, 0, 0, 4, 1, 9, 0, 0, 5},
        {0, 0, 0, 0, 8, 0, 0, 7, 9}
    };

    if (solveSudoku(sudoku))
    {
        printf("Solved Sudoku:\n");
        printSudoku(sudoku);
    }
    else
    {
        printf("No solution exists.\n");
    }

    return 0;
}