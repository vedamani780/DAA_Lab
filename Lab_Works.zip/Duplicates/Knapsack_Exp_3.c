#include <stdio.h>
#include <stdlib.h>
#define MAXN 128
#define MAXW 1024
int K[MAXN + 1][MAXW + 1];
static int max2(int a, int b) { return a > b ? a : b; }
int knapsack01(int n, int w[], int v[], int W, int chosen[], int *ccount)
{
int i, c;
for (c = 0; c <= W; c++) K[0][c] = 0; /* no items -> value 0 */
for (i = 0; i <= n; i++) K[i][0] = 0; /* no space -> value 0 */
for (i = 1; i <= n; i++) {
for (c = 1; c <= W; c++) {
K[i][c] = K[i - 1][c]; /* leave item i */
if (w[i - 1] <= c) { /* or take it */
int take = v[i - 1] + K[i - 1][c - w[i - 1]];
K[i][c] = max2(K[i][c], take);
}
}
}
*ccount = 0; /* recover the item list */
c = W;
for (i = n; i >= 1; i--) {
if (K[i][c] != K[i - 1][c]) {
chosen[(*ccount)++] = i;
c -= w[i - 1];
}
}
return K[n][W];
}
int main(void)
{
int w[] = {2, 3, 4, 5};
int v[] = {3, 4, 5, 6};
int n = 4, W = 8;
int chosen[MAXN], k, i;
int best = knapsack01(n, w, v, W, chosen, &k);
printf("Maximum value = %d\n", best); /* 10 */
printf("Items chosen :");
for (i = k - 1; i >= 0; i--) printf(" %d", chosen[i]);
printf("\n"); /* 2 4 */
return 0;
}